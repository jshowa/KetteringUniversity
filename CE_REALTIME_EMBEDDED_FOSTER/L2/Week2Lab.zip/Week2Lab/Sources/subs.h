#ifndef _subs_week_2
  #define _subs_week_2
  
  #include "derivative.h"
  byte priority(byte*);
  
#endif