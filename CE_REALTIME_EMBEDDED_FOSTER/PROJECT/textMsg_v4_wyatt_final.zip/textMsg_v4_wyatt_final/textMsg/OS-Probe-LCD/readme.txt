readme.txt
----------

**** IMPORTANT: you have to adapt INSTALLPATH in the batchfile.bat! *****

This is a sample project which shows how to use the 'BatchFileRunner'
post-linker plugin to launch the Make utility.
See also the 'BatchFileRunner.txt' file for additional details.

Please see the attached sample batch file and sample mak file.

Metrowerks