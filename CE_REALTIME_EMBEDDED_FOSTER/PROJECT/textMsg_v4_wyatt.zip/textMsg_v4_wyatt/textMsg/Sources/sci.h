#ifndef FOSTER_SPEAKER_H
#define FOSTER_SPEAKER_H


#endif