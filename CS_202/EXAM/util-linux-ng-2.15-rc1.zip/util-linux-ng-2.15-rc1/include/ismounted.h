#ifndef IS_MOUNTED_H
#define IS_MOUNTED_H

extern int is_mounted(const char *file);

#endif /* IS_MOUNTED_H */
